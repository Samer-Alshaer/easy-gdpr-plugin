<?php

/**
 * Plugin Name: Easy GDPR Cookie Compliance 
 * Description: Cookie Compliance for GDPR, European and other cookie law and consent notice requirements on your website.
 * Version: 1.0
 * Author: Samer Alshaer
 * Plugin URI: https://wordpress.org/plugins/easy-gdpr-cookie/
 * Author URI: https://www.facebook.com/SamerAlshaer2020
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once('functions/css.php');
require_once('functions/html.php');
require_once('functions/settings.php');
require_once('accept.php');

if (!function_exists('my_enqueue_easy_gdpr')) {
    function my_enqueue_easy_gdpr()
    {

        wp_enqueue_script('ajax-script', plugins_url('/html/js/gdpr.js', __FILE__), array('jquery'));

        wp_localize_script(
            'ajax-script',
            'ajax_object',
            admin_url('admin-ajax.php')
        );
    }
}
add_action('wp_enqueue_scripts', 'my_enqueue_easy_gdpr');


if (!function_exists('NEW_EasyGDPR_hook')) {
    function NEW_EasyGDPR_hook()
    {
        global $wpdb;
        # name of the table
        $table = $wpdb->prefix . 'Easy_GDPR';

        $create_table = "CREATE TABLE IF NOT EXISTS $table
        (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        PRIMARY KEY(`id`),
        `userID` INT(11) DEFAULT 0,
        `ip_address` VARCHAR(32) NULL,
        `cdate` VARCHAR(30) NOT NULL,
        `reg_date` TIMESTAMP,
         INDEX (userID) 
        )DEFAULT CHARSET=utf8";
        $wpdb->query($create_table);
    }
    register_activation_hook(__FILE__, 'NEW_EasyGDPR_hook');
}
