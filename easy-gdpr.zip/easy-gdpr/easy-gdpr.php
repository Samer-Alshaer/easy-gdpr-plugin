<?php

/**
 * Plugin Name: Easy GDPR Cookie Compliance 
 * Description: Cookie Compliance for GDPR, European and other cookie law and consent notice requirements on your website.
 * Version: 1.0
 * Author: Samer Alshaer
 * Plugin URI: https://wordpress.org/plugins/easy-gdpr-cookie/
 * Author URI: https://www.facebook.com/SamerAlshaer2020
 */

 if( !defined('ABSPATH') ) {
     exit;
 }
 
require_once('functions/css.php');
require_once('functions/html.php');
require_once('functions/settings.php');
require_once('functions/js.php');

if (!function_exists('NEW_EasyGDPR_hook')) {
    function NEW_EasyGDPR_hook()
    {
        global $wpdb;

        # name of the table
        $table = $wpdb->prefix . 'Easy_GDPR';

        $create_table = "CREATE TABLE IF NOT EXISTS $table
        (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        PRIMARY KEY(`id`),
        `userID` INT(11) DEFAULT 0,
        `ip_address` VARCHAR(32) NULL,
        `cdate` VARCHAR(30) NOT NULL,
        `reg_date` TIMESTAMP,
         INDEX (userID) 
        )DEFAULT CHARSET=utf8";
        $wpdb->query($create_table);
       
        //     $create_table = "CREATE TABLE TABLE IF NOT EXISTS `$table`
        //      (
        //         ID INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        //         ip_address VARCHAR(32) NULL,
        //         userID INT(11) DEFAULT 0,
        //         cdate VARCHAR(19) NULL,
        //         reg_date TIMESTAMP,
        //         INDEX (userID)"
              
        //         )DEFAULT CHARSET=utf8";
        //     ");
        // }
    }
    register_activation_hook(__FILE__, 'NEW_EasyGDPR_hook');
}
