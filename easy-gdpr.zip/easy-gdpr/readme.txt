=== NEW Easy GDPR ===
Contributors: Samer Alshaer
Plugin Name: Easy GDPR Cookie Compliance
Tags: gdpr,cookies,security
Requires at least: 5.1
Tested up to: 5.9.1
Requires PHP : 7.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cookie Compliance for GDPR, European and other cookie law and consent notice requirements on your website.
=== Description ===

This plugin is used to get ip address for all users when they are accepted service policy

Features include:
* It can be controlled by admin
* It can be controlled through the settings attached to this plugin
* Built-in WordPress locale codes
* get the ip for security and for Better experience
* Easy To Use
= Installing manually: =

1. Unzip all files to the `wp-content/plugins/EASY-GDPR` directory
2. Log into WordPress admin and activate the 'Easy GDPR' plugin through the 'Plugins' menu
3. Go to *Easy GDPR > Home* in the left-hand menu to start it

=== Changelog===
* 1.0 *
* Avery basic version added for Easy GDPR  system