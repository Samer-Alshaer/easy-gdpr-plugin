<?php 
    header('Content-Type: application/javascript');
    define( 'WP_USE_THEMES', false );
    $vars_file = '../easy-gdpr-vars.php';
    if ( file_exists( $vars_file ) ) {
        require_once( $vars_file );
    }
    if ( isset( $wp_load_path ) ) {
        require_once( $wp_load_path );
    } else {
        require_once( explode( 'wp-content', __FILE__)[0] . 'wp-load.php' );
    }

    $expire = 6*30*24*3600;
    setcookie("gdpr_accept", 'yes' ,time() + $expire,'/'); /* expire in 6 months */

    $ipaddress = sanitize_text_field($_SERVER['REMOTE_ADDR']);

    if(isset($current_user->ID)) {
        $userID = $current_user->ID;
    }
    else {
        $userID = 0;
    }

    $date = date("Y-m-d H:i:s");

    # insert the user information into the database
   echo  $wpdb->query(
        $wpdb->prepare(
        "INSERT INTO {$wpdb->prefix}Easy_GDPR
        ( ip_address, userID, cdate )
        VALUES ( %s, %d, %s )",
        array(
              $ipaddress,
              $userID,
              $date,
           )
        )
     );
    

                       
