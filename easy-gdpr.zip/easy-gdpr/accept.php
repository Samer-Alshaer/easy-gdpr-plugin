<?php
if (!defined('ABSPATH')) {
    exit;
}
add_action('wp_ajax_easy_gdpr_setcookie',  'easy_gdpr_setcookie_fn');
add_action('wp_ajax_nopriv_easy_gdpr_setcookie', 'easy_gdpr_setcookie_fn');

if (!function_exists('easy_gdpr_setcookie_fn')) {
    function easy_gdpr_setcookie_fn()
    {

        $expire = 6 * 30 * 24 * 3600;
        setcookie("gdpr_accept", 'yes', time() + $expire, '/'); /* expire in 6 months */

        $ipaddress = sanitize_text_field($_SERVER['REMOTE_ADDR']);

        if (isset($current_user->ID)) {
            $userID = $current_user->ID;
        } else {
            $userID = 0;
        }

        $date = date("Y-m-d H:i:s");

        # insert the user information into the database
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$wpdb->prefix}Easy_GDPR
        ( ip_address, userID, cdate )
        VALUES ( %s, %d, %s )",
                array(
                    $ipaddress,
                    $userID,
                    $date,
                )
            )
        );
        exit;
    }
}
