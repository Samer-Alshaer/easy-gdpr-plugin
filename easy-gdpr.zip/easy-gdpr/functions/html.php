<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('NEW_EasyGDPR_display')) {
    function NEW_EasyGDPR_display()
    {

        if (isset($_COOKIE['gdpr_accept'])) {
        } else {
            include(plugin_dir_path(__DIR__) . 'html/NEW_EasyGDPR_display.php');
        }
    }
    add_action('wp_footer', 'NEW_EasyGDPR_display');
}
