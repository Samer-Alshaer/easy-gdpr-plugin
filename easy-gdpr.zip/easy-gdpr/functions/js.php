<?php

if( !defined('ABSPATH') ) {
    exit;
}

if (!function_exists('NEW_EasyGDPR_frontend_js')) {
    function NEW_EasyGDPR_frontend_js()
    {
        wp_enqueue_script('google_hosted_jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js');
        wp_enqueue_script('NEW_EasyGDPR_frontend', plugin_dir_url(__DIR__) . '/html/js/gdpr.js');
    }
    add_action('wp_footer', 'NEW_EasyGDPR_frontend_js');
}
