<?php

if( !defined('ABSPATH') ) {
    exit;
}

if (!class_exists('NEW_EasyGDPR')) {
    class NEW_EasyGDPR
    {   

        public function __construct()
        {
            add_action('admin_menu', array($this, 'NEW_EasyGDPR_settings_register'));
            add_action('admin_menu', array($this, 'NEW_EasyGDPR_settings_register2'));
        }

        public function NEW_EasyGDPR_settings_register()
        {
            add_options_page(__('Easy GDPR'), __('Easy GDPR'), 'manage_options', 'easy-gdpr-settings', 'NEW_EasyGDPR_settings_page');
        }

        public function NEW_EasyGDPR_settings_register2()
        {
            add_menu_page(__('Easy GDPR'), __('Easy GDPR'), 'manage_options', __('easy-gdpr-settings'), 'NEW_EasyGDPR_settings_page', 'dashicons-buddicons-groups');
        }
    }
    new NEW_EasyGDPR();
}

if (!function_exists('NEW_EasyGDPR_settings_page')) {
    function NEW_EasyGDPR_settings_page()
    {
        include(plugin_dir_path(__DIR__) . 'html/settings-page.php');
    }
}








