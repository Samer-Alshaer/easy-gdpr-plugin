<?php
$wp_load_path = '/your/custom/path/to/wp-load.php';
