<div class="wrap NEW_EasyGDPR">
    <h2><?php _e("GDPR Settings") ?></h2>
    <?php

    if (isset($_POST['save_gdpr_settings'])) {
        update_option('NEW_EasyGDPR_text', sanitize_text_field($_POST['gdpr_text']));
        update_option('NEW_EasyGDPR_button_text', sanitize_text_field($_POST['gdpr_button_text']));
    ?>
        <div id="setting-error-settings_updated" class="notice notice-success settings-error is-dismissible">
            <p><strong><?php _e('GDPR Settings have been updated.'); ?></strong></p>
        </div>
    <?php
    }

    $gdpr_text = get_option('NEW_EasyGDPR_text', '');
    $gdpr_button_text = get_option('NEW_EasyGDPR_button_text', '');

    ?>

    <form action="" method="post">
        <label for="gdpr_text"><?php _e('GDPR TEXT'); ?></label>
        <textarea name="gdpr_text" id="gdpr_text" cols="30" rows="10" placeholder="GDPR Frontend Text"><?php esc_attr_e($gdpr_text) ?></textarea>

        <label for="gdpr_button_text"><?php _e('Button Text'); ?></label>
        <input type="text" name="gdpr_button_text" placeholder="GDPR Button Text" value="<?php esc_attr_e($gdpr_button_text) ?>" class="widefat">

        <div class="btn_container">
            <input type="submit" name="save_gdpr_settings" class="button button-primary" value="SAVE GDPR SETTINGS">
        </div>
    </form>

    <?php
    global $wpdb;
    $get = $wpdb->get_results("SELECT * FROM  " . $wpdb->prefix . "Easy_GDPR ORDER BY ID DESC");
    ?>

    <table class="show-table">
        <thead>
            <tr class="NEW_EasyGDPR_table_title">
                <th class="NEW_EasyGDPR_show_table" colspan="4"><?php _e("USERS") ?></th>
            </tr>
            <tr class="NEW_EasyGDPR_table_title">
                <th class="NEW_EasyGDPR_show_table"><?php _e("ID") ?></th>
                <th class="NEW_EasyGDPR_show_table"><?php _e("IP ADDRESS") ?></th>
                <th class="NEW_EasyGDPR_show_table"><?php _e("UserID") ?></th>
                <th class="NEW_EasyGDPR_show_table"><?php _e("Date") ?></th>
            </tr>
        </thead>

        <tbody>

            <?php
            foreach ($get as $k => $v) {
            ?>
                <tr>
                    <td class="NEW_EasyGDPR_show_table"><?php esc_html_e($v->id) ?></td>
                    <td class="NEW_EasyGDPR_show_table"><?php esc_html_e($v->ip_address) ?></td>
                    <td class="NEW_EasyGDPR_show_table"><?php esc_html_e($v->userID) ?></td>
                    <td class="NEW_EasyGDPR_show_table"><?php esc_html_e($v->cdate) ?></td>
                </tr>
            <?php
            }

            ?>
        </tbody>
    </table>
</div>