
<div class="NEW_EasyGDPR_display_container" id="NEW_EasyGDPR_display_container">
    <p class="NEW_EasyGDPR_text">
        <?php esc_html_e( get_option('NEW_EasyGDPR_text', __('نستخدم في موقعنا ملف تعريف الارتباط (كوكيز)، لعدة أسباب، منها تقديم ما يهمك من مواضيع، وكذلك تأمين سلامة الموقع والأمان فيه، منحكم تجربة قريبة على ما اعدتم عليه في مواقع التواصل الاجتماعي، وكذلك تحليل طريقة استخدام موقعنا من قبل المستخدمين والقراء.'))) ?>
    </p>

    <button class="NEW_EasyGDPR_accept" id="NEW_EasyGDPR_accept">
        <?php esc_html_e(get_option('NEW_EasyGDPR_button_text', __('موافق'))) ?>
    </button>
</div>