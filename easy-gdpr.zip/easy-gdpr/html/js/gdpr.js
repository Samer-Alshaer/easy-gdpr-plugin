
jQuery(document).ready(function ($) {       

    $("#NEW_EasyGDPR_accept").on("click touchstart",function(e){
           e.preventDefault();
        // Ajax Call
        $.ajax({
            url : ajax_object,
            type : 'POST',
            data : {
                action : 'easy_gdpr_setcookie',
            },
            success : function() {
                 $("#NEW_EasyGDPR_display_container").remove();
            },
        });
        return  false;
    });
});
