$("#NEW_EasyGDPR_accept").on("click touchstart",function(e){
    e.preventDefault();
    
    var dataurl = $("#NEW_EasyGDPR_display_container").data('url');

    $.ajax({
        url: dataurl,
        success:function() {
            /* remov box when selected*/
            $("#NEW_EasyGDPR_display_container").remove();
        }
    });

});